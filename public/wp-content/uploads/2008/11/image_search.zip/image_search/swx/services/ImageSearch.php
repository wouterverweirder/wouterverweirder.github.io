<?php

	require_once('../BaseService.php');
	require_once("../../simple_html_dom.php");
	require_once("../lib/phpFlickr/phpFlickr.php");
	
	//SXC settings
	define('SXC_SEARCH_URL', 'http://www.sxc.hu/browse.phtml?f=search&w=1');
	define('SXC_SEARCH_PARAM', 'txt');
	define('SXC_PAGEING_PARAM', 'p');
	define('SXC_DETAIL_URL', 'http://www.sxc.hu/');
	define('SXC_THUMB_URL', 'http://www.sxc.hu/');
	
	//Morguefile settings
	define('MORGUEFILE_SEARCH_URL', 'http://www.morguefile.com/archive/index.php?display=');
	define('MORGUEFILE_SEARCH_PARAM', 'terms');
	define('MORGUEFILE_PAGEING_PARAM', 'start');
	define('MORGUEFILE_DETAIL_URL', 'http://www.morguefile.com');
	
	//Google settings
	define('GOOGLE_SEARCH_URL', 'http://ajax.googleapis.com/ajax/services/search/images?v=1.0&rsz=large');
	define('GOOGLE_SEARCH_PARAM', 'q');
	define('GOOGLE_PAGEING_PARAM', 'start');
	
	//Flickr settings
	//change this API key to your own flickr API key
	define('FLICKR_API_KEY', 'YOUR_KEY_HERE');

	class ImageSearch extends BaseService
	{
		
		function searchSxc($searchString, $page = 1)
		{
			if(empty($page)) $page = 1;
			//build the url
			$url = SXC_SEARCH_URL;
			$url .= '&' . SXC_SEARCH_PARAM . '=' . urlencode($searchString);
			$url .= '&' . SXC_PAGEING_PARAM . '=' . $page;
			//call the url
			$response = $this->_call($url);
			$dom = new simple_html_dom();
			$dom->load($response);
			$result = array();
			//total results
			$result['total'] = 0;
			$result['page'] = $page;
			$totalElement = $dom->find('div.wbd div.wbd2 div.wbr');
			if(!empty($totalElement) && !empty($totalElement[0]))
			{
				$totalInnerText =  "" . $totalElement[0]->innerText();
				$totalSplit = split(' ', $totalInnerText);
				$result['total'] += $totalSplit[0];
			}
			//resultset
			$result['results'] = array();
			foreach($dom->find('#thumbs div.thumb div.thumb_img a') as $thumbElement)
			{
				$imageLink = $thumbElement->href;
				if(!(strpos($imageLink, 'http://') === 0)) $imageLink = SXC_DETAIL_URL . $imageLink;
				$thumbUrl = $thumbElement->children(0)->src;
				if(!(strpos($thumbUrl, 'http://') === 0)) $thumbUrl = SXC_THUMB_URL . $thumbUrl;
				//
				$thumb = array();
				$thumb['imageLink'] = $imageLink;
				$thumb['thumbnail'] = $thumbUrl;
				$result['results'][] = $thumb;
			}			
			$dom->clear();
       		return $result;
		}

		function searchMorgueFile($searchString, $page = 1)
		{
			if(empty($page)) $page = 1;
			$start = 0;
			if(!empty($page) && is_numeric($page))
			{
				$start = ($page - 1) * 12;
			}
			//build the url
			$url = MORGUEFILE_SEARCH_URL;
			$url .= '&' . MORGUEFILE_SEARCH_PARAM . '=' . urlencode($searchString);
			$url .= '&' . MORGUEFILE_PAGEING_PARAM . '=' . $start;
			//call the url
			$response = $this->_call($url);
			$dom = new simple_html_dom();
			$dom->load($response);
			$result = array();
			//total results
			$result['total'] = 0;
			$totalElement = $dom->find('div.nav_element form table tr td div[align=right] b');
			if(!empty($totalElement) && !empty($totalElement[0]))
			{
				$result['total'] += $totalElement[0]->innerText();
			}
			$result['page'] = $page;
			foreach($dom->find('div.nav_element table tr td a') as $thumbElement)
			{
				$imgElement = $thumbElement->find('img');
				if(!empty($imgElement))
				{
					//error_log($imgElement[0]);
					$thumb = array();
					$thumb['imageLink'] = MORGUEFILE_DETAIL_URL . $thumbElement->href;
					$thumb['thumbnail'] = $imgElement[0]->src;
					$result['results'][] = $thumb;
				}
			}
			$dom->clear();
       		return $result;
		}
		
		function searchGoogle($searchString, $page = 1)
		{
			if(empty($page)) $page = 1;
			$start = 0;
			if(!empty($page) && is_numeric($page))
			{
				$start = ($page - 1) * 8;
			}
			//build the url
			$url = GOOGLE_SEARCH_URL;
			$url .= '&' . GOOGLE_SEARCH_PARAM . '=' . urlencode($searchString);
			$url .= '&' . GOOGLE_PAGEING_PARAM . '=' . $start;
			//call the url
			$response = $this->_jsonCall($url);
			$result = array();
			$result['total'] = 0;
			$result['page'] = $page;
			$result['results'] = array();
			if(!empty($response->responseData))
			{
				if(!empty($response->responseData->cursor))
				{
					$result['total'] = $response->responseData->cursor->estimatedResultCount;
				}
				if(!empty($response->responseData->results))
				{
					foreach($response->responseData->results as $searchResult)
					{
						$thumb = array();
						$thumb['imageLink'] = $searchResult->url;
						$thumb['thumbnail'] = $searchResult->tbUrl;
						$result['results'][] = $thumb;
					}
				}
			}
       		return $result;
		}
		
		function searchFlickr($searchString, $page = 1)
		{
			if(empty($page)) $page = 1;
			$phpFlickr = new phpFlickr(FLICKR_API_KEY);
			$args = array('text' => $searchString, 'per_page' => 25, 'page' => $page);
		    $response = $phpFlickr->photos_search($args);
		    $result['total'] = 0;
			$result['page'] = $page;
			$result['results'] = array();
			if($response)
		    {
		    	$result['total'] = $response['total'];
		    	$result['page'] = $response['page'];
		    	foreach($response['photo'] as $photo)
		    	{
		    		$thumb = array();
		    		$thumb['imageLink'] = 'http://farm' . $photo['farm'] . '.static.flickr.com/' . $photo['server'] . '/' . $photo['id'] . '_' . $photo['secret'] . '.jpg';
		    		$thumb['thumbnail'] = 'http://farm' . $photo['farm'] . '.static.flickr.com/' . $photo['server'] . '/' . $photo['id'] . '_' . $photo['secret'] . '_t.jpg';
		    		$result['results'][] = $thumb;
		    	}
		    }
			return $result;
		}
		
	}
?>
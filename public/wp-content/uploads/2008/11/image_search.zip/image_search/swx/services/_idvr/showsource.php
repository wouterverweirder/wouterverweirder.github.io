<?php
	
	// Displays the source of the requested file.
	$file = $_GET['file'];
	
	highlight_file($file);

?>
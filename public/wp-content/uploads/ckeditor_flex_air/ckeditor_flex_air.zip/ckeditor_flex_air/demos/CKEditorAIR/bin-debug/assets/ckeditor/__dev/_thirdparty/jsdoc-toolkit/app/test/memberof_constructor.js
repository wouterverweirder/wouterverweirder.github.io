/** @constructor */
function Circle(){}

/**
 @constructor
 @memberOf Circle.prototype
 */
Tangent = function(){};

/**
	@member Circle.prototype.Tangent.prototype
*/
getDiameter = function(){};



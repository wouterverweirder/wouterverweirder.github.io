#!/bin/bash

# Copyright (c) 2003-2009, CKSource - Frederico Knabben. All rights reserved.
# For licensing, see LICENSE.html or http://ckeditor.com/license

# Checks translation files in given directory.

java -jar langtool/langtool.jar ../../_source/lang
